import {SyncRepository,RepositoryError} from './repository.js';
import {validateEnvelope,validateVault,unbase64,requireUUID,keyVersion,MAX_REQUEST_BYTES,MAX_BATCH_RECORDS,bytesLength} from '../../core/sync/protocol.js';
import {digest} from '../../core/sync/crypto.js';
import {handleCalendarFeed} from './calendar.js';
import {handleAI} from './ai.js';
const response=(value,status=200,extra={})=>new Response(JSON.stringify(value),{status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer',...extra}});
async function body(request){if(Number(request.headers.get('content-length'))>MAX_REQUEST_BYTES)throw new RepositoryError('request_limit','Request exceeds 5 MB.',413);const reader=request.body?.getReader();let size=0,text='';if(reader){const decoder=new TextDecoder();for(;;){const item=await reader.read();if(item.done)break;size+=item.value.length;if(size>MAX_REQUEST_BYTES){await reader.cancel();throw new RepositoryError('request_limit','Request exceeds 5 MB.',413);}text+=decoder.decode(item.value,{stream:true});}text+=decoder.decode();}if(!text)return {};try{return JSON.parse(text);}catch{throw new RepositoryError('invalid_json','Expected a JSON body.',400);}}
export async function handleRequest(request,env){
  if(/\/api\/ai\/?$/.test(new URL(request.url).pathname))return handleAI(request,env);
  if(/\/api\/ics(?:\/|$)/.test(new URL(request.url).pathname))return handleCalendarFeed(request,env);
  const url=new URL(request.url),path=url.pathname.replace(/^.*\/api\/sync/,'')||'/',repo=new SyncRepository(env);
  try{
    if(url.protocol!=='https:')return response({error:'HTTPS is required.',code:'https_required'},426);
    if(request.headers.get('origin')&&request.headers.get('origin')!==url.origin||request.headers.get('sec-fetch-site')==='cross-site')return response({error:'Only same-origin requests are accepted.',code:'origin'},403);
    if(request.method==='OPTIONS')return response({error:'Cross-origin API access is disabled.',code:'origin'},403);
    if(path==='/checks'&&request.method==='GET'){const checks=await repo.checks();return response({protocol:1,provider:'cloudflare',ready:checks.every(row=>row.passed),checks});}
    if(!env.DB||!env.BLOBS||typeof env.AUTH_PEPPER!=='string'||env.AUTH_PEPPER.length<32)return response({error:'Server bindings or authentication secret are not configured.',code:'not_configured'},503);
    const window=Math.floor(Date.now()/60000),sensitive=['/recover','/vault'].includes(path),bucket=await digest(`${env.AUTH_PEPPER}:${request.headers.get('cf-connecting-ip')??'unknown'}:${sensitive?'identity':'sync'}:${window}`);
    if(!await repo.rate(bucket,window,sensitive?30:Number(env.RATE_PER_MINUTE)||600))return response({error:'Rate limit reached. Retry after one minute.',code:'rate_limit'},429,{'Retry-After':'60'});
    if(path==='/vault'&&request.method==='GET'){const id=requireUUID(url.searchParams.get('vaultId')),vault=await repo.getVault(id);if(!vault)return response({error:'Vault not found.',code:'vault_missing'},404);return response({vaultId:id,salt:vault.salt,keyVersion:vault.key_version,createdAt:vault.created_at});}
    if(path==='/recover'&&request.method==='POST'){const input=await body(request);requireUUID(input.vaultId);unbase64(input.codeId,{length:16});const vault=await repo.getVault(input.vaultId),wrapped=vault?JSON.parse(vault.wrapped_keys).find(row=>row.codeId===input.codeId):null;if(!wrapped)return response({error:'Recovery code was not found.',code:'recovery_missing'},404);return response({vaultId:input.vaultId,keyVersion:vault.key_version,wrappedKey:wrapped});}
    const token=request.headers.get('authorization')?.match(/^Bearer ([A-Za-z0-9_-]+)$/)?.[1];if(!token)return response({error:'Vault authentication is required.',code:'unauthorized'},401);unbase64(token,{length:32});
    if(path==='/vault'&&request.method==='POST'){const input=validateVault(await body(request));if((input.keyVersion??1)!==1||await digest(token)!==input.authHash)return response({error:'Vault authentication binding is invalid.',code:'auth_binding'},400);const created=await repo.create(input,token);return response({vaultId:input.vaultId,keyVersion:1},created.created?201:200);}
    const id=requireUUID(request.headers.get('x-waypost-vault')),version=keyVersion(Number(request.headers.get('x-waypost-key-version'))),vault=await repo.getVault(id);
    if(!vault||!await repo.verifyToken(token,vault.auth_hash))return response({error:'Vault authentication failed. Unlock the vault again.',code:'unauthorized'},401);
    if(version!==vault.key_version)return response({error:'Vault keys changed. Unlock again.',code:'key_version_changed'},409);
    if(path==='/calendar'&&request.method==='GET')return response(await repo.calendarStatus(id));
    if(path==='/calendar'&&['POST','PUT'].includes(request.method))return response(await repo.saveCalendar(vault,token,await body(request),{create:request.method==='POST'}));
    if(path==='/calendar'&&request.method==='DELETE')return response(await repo.revokeCalendar(vault,(await body(request)).expectedVersion));
    if(path==='/changes'&&request.method==='GET'){const since=Number(url.searchParams.get('since')??0);if(!Number.isSafeInteger(since)||since<0)throw new RepositoryError('cursor','Invalid cursor.',400);return response(await repo.list(vault,since));}
    if((path==='/changes'||path==='/vault/rotation/changes')&&request.method==='POST'){const input=await body(request);if(!Array.isArray(input.changes)||input.changes.length>MAX_BATCH_RECORDS)throw new RepositoryError('batch_limit',`Use at most ${MAX_BATCH_RECORDS} records per batch.`,413);input.changes.forEach(validateEnvelope);const unique=new Set(input.changes.map(row=>row.type+':'+row.id));if(unique.size!==input.changes.length)throw new RepositoryError('duplicate','Duplicate record in batch.',400);
      let rotationId=null;if(path.includes('/rotation/')){rotationId=requireUUID(input.rotationId);const pending=await repo.rotation(id);if(!pending||pending.rotation_id!==rotationId)throw new RepositoryError('rotation_missing','Pending key rotation not found.');}
      return response({cursor:await repo.write(vault,input.changes,rotationId)});
    }
    if(path==='/vault/rotation'&&request.method==='GET'){const row=await repo.rotation(id);return response({pending:row?{rotationId:row.rotation_id,baseCursor:row.base_cursor,createdAt:row.created_at}:null});}
    if(path==='/vault/rotation'&&request.method==='POST'){const input=validateVault(await body(request));requireUUID(input.rotationId);unbase64(input.newAuthToken,{length:32});if(input.vaultId!==id||input.keyVersion!==version+1||await digest(input.newAuthToken)!==input.authHash||!Number.isSafeInteger(input.baseCursor)||input.baseCursor<0)throw new RepositoryError('rotation_metadata','Invalid replacement key metadata.',400);await repo.startRotation(vault,input);return response({rotationId:input.rotationId},201);}
    if(path==='/vault/rotation/commit'&&request.method==='POST'){const input=await body(request);requireUUID(input.rotationId);if(!Number.isSafeInteger(input.count)||input.count<0)throw new RepositoryError('rotation_count','Invalid staged record count.',400);const next=await repo.commitRotation(vault,input.rotationId,input.count);return response({keyVersion:next.key_version,cursor:next.cursor});}
    if(path==='/vault/rotation'&&request.method==='DELETE'){const input=await body(request);if(input.rotationId)requireUUID(input.rotationId);await repo.cancelRotation(vault,input.rotationId);return response({cancelled:true});}
    if(path==='/vault'&&request.method==='DELETE'){await repo.remove(vault);return response({deleted:true});}
    return response({error:'Sync route not found.',code:'not_found'},404);
  }catch(error){if(error instanceof RepositoryError)return response({error:error.message,code:error.code},error.status);if(/CHECK constraint failed|rotation_quota/.test(error.message))return response({error:'Vault quota exceeded.',code:'vault_limit'},413);if(/key_version_changed/.test(error.message))return response({error:'Vault keys changed. Unlock again.',code:'key_version_changed'},409);if(error instanceof TypeError||/Invalid|invalid|UUID|Exactly|Duplicate|record|encoded|UTC|recovery wrapper/.test(error.message))return response({error:error.message,code:'invalid_input'},400);return response({error:'Sync storage operation failed.',code:'storage'},503);}
}
export default {fetch(request,env){return handleRequest(request,env);}};
